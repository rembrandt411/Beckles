player_manager.AddValidModel( "jawa", "models/jawacustom.mdl" )
list.Set( "PlayerOptionsModel", "jawa", "models/jawacustom.mdl" )
